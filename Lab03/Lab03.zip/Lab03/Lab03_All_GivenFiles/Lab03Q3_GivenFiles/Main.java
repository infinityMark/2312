import java.util.*;
import java.io.*;

public class Main{
	
	//Your task:
	//Todo(1) the main() method --- see Main_GivenCode.txt
	//Todo(2) the createTeams() method --- see Main_GivenCode.txt
	//Todo(3) the decideTasks() method --- see Main_GivenCode.txt
}
