public class Task {
	
	//Instance fields
	private __________name; //A reference to the task name: String name;
	
	//Constructor
	public Task(_______________) //One input parameter: String name
	{
		this.name = ______________;
	}
	
	//Return the String representation 
	public String toString()
	{
		_____________________;//Return the task name: return name;
	}
}