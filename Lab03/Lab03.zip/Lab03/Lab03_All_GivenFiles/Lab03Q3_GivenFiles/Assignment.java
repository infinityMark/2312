public class Assignment 
{
	//Instance fields
	private ___________team; //a reference to the team for this assignment: Team team;
	private ___________task; //a reference to the task assigned: Task task;
	
	//Constructor
	public Assignment(_________________) //Two input parameters: Team aTeam, Task aTask
	{
		team = ______________;
		task = ______________;
	}
	
	//Return the task name
	public String getTaskName()
	{
		return _________________;//The task name to be returned: task.toString();
	}
	
	//Return the String representation for this assignment
	public String toString()
	{
		return _________________;//The string representation of this assignment: task.toString() + " " + team.toString();
	}
	
	//print the team who are assigned with a task of the given task name
	public static void printTaskTeam(String taskName, Assignment[] assignments)
	{
		for (int i=0;i<assignments.length;i++)
			if (_______________________________)//check the name: assignments[i].getTaskName().equals(taskName)
				System.out.println(_____________________); //print the assignment: assignments[i].toString()
	}
}