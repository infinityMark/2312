import java.io.*;
import java.util.Scanner;

public class Student {

	//Instance fields
	private __________name; //A reference to the student name: String name;
	
	//Constructor
	public Student(_______________) //One input parameter: String name
	{
		this.name = _____________;
	}
	
	//Return the String representation 
	public String toString()
	{
		_____________________;//Return the student name: return name;
	}
	
	//Static method for reading a list of students from the file and return an array of student objects
	public static Student[] createStudentListFromFile(String filepathname) throws FileNotFoundException
	{
		int count;
		
		Scanner inFile = new Scanner(new File(filepathname));
		
		count=inFile.nextInt(); //read the count
		inFile.nextLine(); //skip line break (otherwise the first .nextLine in the following loop will read an empty line)

		//Prepare the array of student object references
		_______________result; //An array of students: Student[] result;
		result = ___________; //Create the students array: new Student[count];		

		for (int i=0;i<count;i++)
		{
			String name = ____________; //Read a line of student name: inFile.nextLine();
			result[i] = ______________; //Create a student object for result[i]: new Student(name);
		}
		
		______________;//Close the file: inFile.close();
		______________;//Return the result: return result;
	}
	
}