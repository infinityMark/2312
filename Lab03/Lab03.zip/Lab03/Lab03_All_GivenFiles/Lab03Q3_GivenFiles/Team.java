public class Team 
{
	//Instance fields
	private ____________students; //A reference to the array of students in the team: Student [] students;
	private __________name; //A reference to the team name: String name;
	
	//Constructor
	public Team(_____________________) //Two input parameters: String name, Student[] students
	{
		this.name = _____________;
		this.students = _______________;
	}
	
	//Return the String representation for the team: name + student list
	public String toString()
	{
		String result = ___________ + ": "; //Team name: name
		for (int i=0; __________________; i++) //Loop through students[0..students.length-1]
		{
			result += "["+____________________+"] "; //Student names: students[i].toString()
		}
		
		____________; //Return the result: return result;
	}
	
	//Return the team name
	public String getName()
	{
		______________;//Return the team name: return name;
	}
}